<?php

use App\Http\Controllers\StudentRegisterController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', function () {
    return view('index');
});
Route::get('/download', function () {
    return view('downloadform');
});
Route::get('/register', function () {
    return view('form');
});

Route::post('/pdf',[StudentRegisterController::class,'pdfgen']);

Route::get('/admin',[StudentRegisterController::class,'adminindex']);

Route::get('/show/{id}',[StudentRegisterController::class,'showstudent']);

Route::post('/reg',[StudentRegisterController::class,'StudRegister']);
