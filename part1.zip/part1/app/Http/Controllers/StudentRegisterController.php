<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
use Barryvdh\DomPDF\Facade\Pdf;

class StudentRegisterController extends Controller
{
    public function StudRegister(Request $request){
        $request->validate([
        'name' => 'required',
        'gender' => 'required',
        'email' => 'required',
        'studimg' => 'required',
        'phno' => 'required',
        'fathername' => 'required',
        'mothername' => 'required',
        'address' => 'required',
        'city' => 'required',
        'State' => 'required',
        'pincode' => 'required',
        'course' => 'required',
      ]);

      $student=new Student();
      $student->name=$request->input('name');
      $student->email=$request->input('email');
      $student->phno=$request->input('phno');
      $student->gender=$request->input('gender');
      $student->fathername=$request->input('fathername');
      $student->mothername=$request->input('mothername');
      $student->address=$request->input('address');
      $student->state=$request->input('State');
      $student->city=$request->input('city');
      $student->pincode=$request->input('pincode');
      $student->course=$request->input('course');
      $img=$request->file('studimg');
      $imgoriginalname=$img->getClientOriginalName();
      $imagename=time().$imgoriginalname;
      $img->move('images/Students/',$imagename);

      $student->studimg=$imagename;
      $student->save();

      return redirect('/register')->with(['msg'=>'Student Register Successfully ---go download a form','status'=>'success']);
    }


    public function adminindex(){
        $students=Student::paginate(5);
        return view('admin',compact('students'));
    }

    public function showstudent($id){
        $students=Student::whereId($id)->get();
        return view('viewstudent',compact('students'));
    }

    public function pdfgen(Request $request){
        $request->validate([
            'email'=>'required|email|exists:students,email'
        ]);
        $datas=Student::where('email',$request->input('email'))->get();
        $pdf = Pdf::loadView('pdf.information',compact('datas'));
        return $pdf->download(date('d-m-y').'-registration.pdf');
    }
}
