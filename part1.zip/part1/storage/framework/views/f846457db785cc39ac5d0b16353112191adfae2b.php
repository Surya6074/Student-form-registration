<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="stylesheet" href="./css/style.css" />
    <!-- Bootstrap links -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
    />

    <!-- TailWind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
  </head>
  <body>
    <div class="container pt-2">
      <div class="flex p-12 justify-between">
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <a href="/admin"><i class="bi bi-arrow-left text-3xl"></i></a>
        <h1 class="h1 text-center">Student#<?php echo e($stud->id); ?></h1>
        <a href=""></a>
      </div>
      <div class="container">
        <div class="flex bg-gray-200 p-16 justify-around">
          <table>
            <tr>
              <td><p class="font-semibold text-2xl">Name</p></td>
              <td>
                <p class="font-semibold text-2xl">&nbsp;&nbsp;:&nbsp;&nbsp;</p>
              </td>
              <td><p class="text-2xl"><?php echo e($stud->name); ?></p></td>
            </tr>

            <tr>
              <td><p class="font-semibold text-2xl">Registration Id</p></td>
              <td>
                <p class="font-semibold text-2xl">&nbsp;&nbsp;:&nbsp;&nbsp;</p>
              </td>
              <td><p class="text-2xl"><?php echo e($stud->id); ?></p></td>
            </tr>

            <tr>
              <td><p class="font-semibold text-2xl">Email Id</p></td>
              <td>
                <p class="font-semibold text-2xl">&nbsp;&nbsp;:&nbsp;&nbsp;</p>
              </td>
              <td><p class="text-2xl"><?php echo e($stud->email); ?></p></td>
            </tr>
            <tr>
              <td><p class="font-semibold text-2xl">Course</p></td>
              <td>
                <p class="font-semibold text-2xl">&nbsp;&nbsp;:&nbsp;&nbsp;</p>
              </td>
              <td><p class="text-2xl"><?php echo e($stud->course); ?></p></td>
            </tr>
          </table>
          <div class="img">
            <img
              src="<?php echo e(asset('images/Students/'.$stud->studimg)); ?>"
              width="200px"
              height="200px"
              alt=""
            />
          </div>
        </div>
        <div class="mt-8 bg-gray-200">
          <h3 class="h3 text-center p-4">Student Information</h3>
          <div class="flex justify-around px-16 py-8 pb-16">
            <table>
              <tr>
                <td><p class="font-semibold text-2xl">Gender</p></td>
                <td>
                  <p class="font-semibold text-2xl">
                    &nbsp;&nbsp;:&nbsp;&nbsp;
                  </p>
                </td>
                <td><p class="text-2xl"><?php echo e($stud->gender); ?></p></td>
              </tr>

              <tr>
                <td><p class="font-semibold text-2xl">Phone Number</p></td>
                <td>
                  <p class="font-semibold text-2xl">
                    &nbsp;&nbsp;:&nbsp;&nbsp;
                  </p>
                </td>
                <td><p class="text-2xl"><?php echo e($stud->phno); ?></p></td>
              </tr>
              <tr>
                <td><p class="font-semibold text-2xl">Father's Name</p></td>
                <td>
                  <p class="font-semibold text-2xl">
                    &nbsp;&nbsp;:&nbsp;&nbsp;
                  </p>
                </td>
                <td><p class="text-2xl"><?php echo e($stud->fathername); ?></p></td>
              </tr>

              <tr>
                <td><p class="font-semibold text-2xl">Mother's Name</p></td>
                <td>
                  <p class="font-semibold text-2xl">
                    &nbsp;&nbsp;:&nbsp;&nbsp;
                  </p>
                </td>
                <td><p class="text-2xl"><?php echo e($stud->mothername); ?></p></td>
              </tr>
            </table>
            <table>
              <tr>
                <td><p class="font-semibold text-2xl">Address</p></td>
                <td>
                  <p class="font-semibold text-2xl">
                    &nbsp;&nbsp;:&nbsp;&nbsp;
                  </p>
                </td>
                <td><p class="text-2xl"><?php echo e($stud->address); ?></p></td>
              </tr>

              <tr>
                <td><p class="font-semibold text-2xl">City</p></td>
                <td>
                  <p class="font-semibold text-2xl">
                    &nbsp;&nbsp;:&nbsp;&nbsp;
                  </p>
                </td>
                <td><p class="text-2xl"><?php echo e($stud->city); ?></p></td>
              </tr>

              <tr>
                <td><p class="font-semibold text-2xl">State</p></td>
                <td>
                  <p class="font-semibold text-2xl">
                    &nbsp;&nbsp;:&nbsp;&nbsp;
                  </p>
                </td>
                <td><p class="text-2xl"><?php echo e($stud->state); ?></p></td>
              </tr>

              <tr>
                <td><p class="font-semibold text-2xl">Pincode</p></td>
                <td>
                  <p class="font-semibold text-2xl">
                    &nbsp;&nbsp;:&nbsp;&nbsp;
                  </p>
                </td>
                <td><p class="text-2xl"><?php echo e($stud->pincode); ?></p></td>
              </tr>
            </table>
          </div>
        </div>
      </div>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </body>
  <style>
    td {
      padding-top: 15px;
    }
  </style>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-tutor\StudentRegisterForm\resources\views/viewstudent.blade.php ENDPATH**/ ?>