<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="stylesheet" href="./css/style.css" />
    <!-- Bootstrap links -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
    />

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <!-- TailWind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="<?php echo e(asset('js/validation.js')); ?>"></script>
  </head>
  <body>
    <div class="p-12">
        <?php if(session('msg')): ?>
        <div class="alert alert-success">
            Thanks for Registraion! Claim your Registration document <a class="text-blue underline" href="/download">Click here</a>
        </div>
        <?php endif; ?>
    </div>

    <div class="container mt-8 mb-8">
      <div class="flex justify-between">
        <a href="/"><i class="bi bi-arrow-left text-4xl"></i></a>
        <p class="h1 text-center mb-4">Student Register Form</p>
        <div class=""></div>
      </div>
      <form id="insertForm" action="/reg" method="POST" enctype="multipart/form-data">
        <div class="">
            <?php echo csrf_field(); ?>
          <div class="inp mb-3">
            <label for="formControlInput" class="form-label"
              >Enter a Name</label
            >
            <input
              type="text"
              class="form-control"
              id="formControlInput"
              placeholder="Name"
              name="name"
            />
          </div>

          <div class="inp mb-3">
            <label for="" class="mr-32">Gender</label>
            <div class="flex flex-row mt-1">
              <div class="form-check mr-8">
                <input
                  class="form-check-input"
                  type="radio"
                  name="gender"
                  id="formRadioDefault"
                  checked=''
                  value="Male"
                />
                <label class="form-check-label" for="formRadioDefault"
                  >Male</label
                >
              </div>
              <div class="form-check">
                <input
                  class="form-check-input"
                  type="radio"
                  name="gender"
                  id="gender"
                  value="Female"
                />
                <label class="form-check-label" for="formRadioChecked"
                  >Female</label
                >
              </div>
            </div>
          </div>

          <div class="inp mb-3">
            <label for="formControlInput" class="form-label"
              >Email address</label
            >
            <input
              type="email"
              class="form-control"
              id="email"
              placeholder="name@example.com"
              name="email"
            />
          </div>
          <div class="inp mb-3">
            <label for="formFile" class="form-label">Upload ur image</label>
            <input class="form-control" type="file" name="studimg" id="formFile">
          </div>
          <div class="inp mb-3">
            <label for="formControlInput" class="form-label"
              >Enter a Phone Number</label
            >
            <input
              type="number"
              class="form-control"
              id="phno"
              placeholder="1234567890"
              name="phno"
            />
          </div>

          <div class="inp mb-3">
            <label for="formControlInput" class="form-label"
              >Enter a father Name</label
            >
            <input
              type="text"
              class="form-control"
              id="fathername"
              placeholder="Father's Name"
              name="fathername"
            />
          </div>
          <div class="inp mb-3">
            <label for="formControlInput" class="form-label"
              >Enter a Mother Name</label
            >
            <input
              type="text"
              class="form-control"
              id="mothername"
              placeholder="Mother's Name"
              name="mothername"
            />
          </div>
          <div class="inp mb-3">
            <label for="formControlInput" class="form-label"
              >Enter a Address</label
            >
            <input
              type="text"
              class="form-control"
              id="address"
              placeholder="Address"
              name="address"
            />
          </div>
          <div class="inp flex flex-row w-full mb-3">
            <div class="w-full mr-2">
              <label for="formControlInput" class="form-label"
                >Enter a City</label
              >
              <input
                type="text"
                class="form-control"
                id="city"
                placeholder="City"
                name="city"
              />
            </div>
            <div class="w-full mx-2">
              <label for="formControlInput" class="form-label"
                >Enter a state</label
              >
              <input
                type="text"
                class="form-control"
                id="State"
                placeholder="state"
                name="State"
              />
            </div>
            <div class="w-full ml-2">
              <label for="formControlInput" class="form-label"
                >Enter a pincode</label
              >
              <input
                type="text"
                class="form-control"
                id="pincode"
                placeholder="625532"
                name="pincode"
              />
            </div>
          </div>
          <div class="inp mb-3">
            <label for="" class="form-label">Select a Course</label>
            <select class="form-select" name="course">
              <option value="BCA">BCA</option>
              <option value="Bsc.Computer Science">Bsc.Computer Science</option>
              <option value="Bsc. IT">Bsc. IT</option>
              <option value="Bsc. Data science">Bsc. Data science</option>
            </select>
          </div>
          <div class="flex flex-row mt-8 mb-32 justify-center">
            <button class="btn btn-Secondary mr-12 py-2 px-4">Reset</button>
            <input type="submit" id="btnsubmit" class="btn btn-primary py-2 px-4" value="Save">
            
          </div>
        </div>
      </form>
    </div>
  </body>
  <style>
      .error {
      color: red;
   }
Most modern browsers
  </style>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-tutor\StudentRegisterForm\resources\views/form.blade.php ENDPATH**/ ?>