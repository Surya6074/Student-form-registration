<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="stylesheet" href="./css/style.css" />
    <!-- Bootstrap links -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <!-- TailWind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
  </head>
  <body>
    <nav class="p-4 flex justify-around items-center bg-gray-200">
      <p class="h1">Admin panel</p>
      <button></button>
      <button></button>
    </nav>
    <div class="container mt-12">
      <p class="h1 text-center">Students Data</p>
      <table class="table mt-8 table-striped table-hover text-center">
        <thead>
          <tr>
            <th>Register Id</th>
            <th>Name</th>
            <th>Email</th>
            <th>Courses</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($stud->id); ?></td>
                <td><?php echo e($stud->name); ?></td>
                <td><?php echo e($stud->email); ?></td>
                <td><?php echo e($stud->course); ?></td>
                <td><a href="/show/<?php echo e($stud->id); ?>" class="btn btn-primary">View</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <?php echo e($students->links()); ?>


      </table>
    </div>
  </body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-tutor\StudentRegisterForm\resources\views/admin.blade.php ENDPATH**/ ?>