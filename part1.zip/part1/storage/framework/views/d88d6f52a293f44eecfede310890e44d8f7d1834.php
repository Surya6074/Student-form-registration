<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration Information</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        .container {
            width: 80%;
            margin: auto;
        }

        h1, h2 {
            text-align: center;
            color: #333;
        }

        section {
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        section img{
            text-align: center;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        p {
            margin: 10px 0;
            font-size: 14px;
        }

        strong {
            display: inline-block;
            width: 150px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Student Registration Successfully!</h1>
        <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <section>
            <h2>Registration Information</h2>
            <img src="<?php echo e(public_path('images/Students/' . $data->studimg)); ?>" width="400px" height="400px" alt="">
            <p><strong>Name:</strong> <?php echo e($data->name); ?></p>
            <p><strong>Registration ID:</strong> <?php echo e($data->id); ?></p>
            <p><strong>Course:</strong> <?php echo e($data->course); ?></p>
            <p><strong>Gender:</strong> <?php echo e($data->gender); ?></p>
            <p><strong>Email:</strong> <?php echo e($data->email); ?></p>
            <p><strong>Phone Number:</strong> <?php echo e($data->phno); ?></p>
            <p><strong>Father's Name:</strong> <?php echo e($data->fathername); ?></p>
            <p><strong>Mother's Name:</strong> <?php echo e($data->mothername); ?></p>
            <p><strong>Address:</strong> <?php echo e($data->address); ?></p>
            <p><strong>City:</strong> <?php echo e($data->city); ?></p>
            <p><strong>State:</strong> <?php echo e($data->state); ?></p>
            <p><strong>PinCode:</strong> <?php echo e($data->pincode); ?></p>
        </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <p>Thank you For Registration !</p>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-tutor\StudentRegisterForm\resources\views/pdf/information.blade.php ENDPATH**/ ?>