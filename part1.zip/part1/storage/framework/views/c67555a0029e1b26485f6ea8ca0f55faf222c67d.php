<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="stylesheet" href="./css/style.css" />
    <!-- Bootstrap links -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"
    />

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <!-- TailWind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="<?php echo e(asset('js/validation.js')); ?>"></script>
  </head>
  <body>

    <div class=" h-full container flex flex-col justify-center items-center">
        <h1 class="h1">Download Registration PDf</h1>
        <form action="/pdf" class="mt-12 w-1/4" method="POST">
            <?php echo csrf_field(); ?>
            <div class="input-group">
            <input type="email" name="email" class="form-control" placeholder="Enter Your Email ID" aria-describedby="input-group-button-right">
            <button type="submit" class="btn btn-primary" id="input-group-button-right">Download</button>
          </div>
        </form>
    </div>
  </body>
  <style>
    body{
        height: 100vh;
        width: 100vw;
    }
  </style>
</html>
<?php /**PATH C:\xampp\htdocs\laravel-tutor\StudentRegisterForm\resources\views/downloadform.blade.php ENDPATH**/ ?>