<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="stylesheet" href="./css/style.css" />
    <!-- Bootstrap links -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <!-- TailWind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
  </head>
  <body>


    <nav class="flex justify-around p-8 pt-16">
      <p class="h1 text-white">College Student Registration Form</p>
      <ul class="flex w-1/4 text-center items-center justify-around">
        <li><a href="/download" class="text-white">Download form</a></li>
      </ul>
    </nav>
    <div class="hero flex flex-col justify-center items-center pt-20 h-3/4">
      <p class="h1 text-white text-5xl pb-4">College Name</p>
      <h2 class="h1 text-white text-8xl pb-4">Explore More Courses</h2>
      <p class="h4 text-white text-3xl pb-4">Register immediately</p>
      <a
        href="/register"
        class="bg-transparent font-semibold hover:text-blue text-white py-3 px-8 border hover:bg-blue-700 hover:border-transparent rounded"
      >
        Register Form
      </a>
    </div>
    <div class="overlay"></div>
    <style>
      body {
        height: 100vh;
        width: 100vw;
        overflow: hidden;
        background-image: url("../images/pexels-pixabay-159740.jpg");
        background-repeat: no-repeat;
        background-position: center;
        background-size: cover;
        position: relative;
        z-index: -2;
      }
      .overlay {
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: black;
        opacity: 0.7;
        z-index: -1;
      }


    </style>
  </body>
</html>
