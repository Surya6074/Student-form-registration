<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration Information</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        .container {
            width: 80%;
            margin: auto;
        }

        h1, h2 {
            text-align: center;
            color: #333;
        }

        section {
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        section img{
            text-align: center;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        p {
            margin: 10px 0;
            font-size: 14px;
        }

        strong {
            display: inline-block;
            width: 150px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Student Registration Successfully!</h1>
        @foreach ($datas as $data)
        <section>
            <h2>Registration Information</h2>
            <img src="{{ public_path('images/Students/' . $data->studimg) }}" width="400px" height="400px" alt="">
            <p><strong>Name:</strong> {{ $data->name }}</p>
            <p><strong>Registration ID:</strong> {{ $data->id }}</p>
            <p><strong>Course:</strong> {{ $data->course }}</p>
            <p><strong>Gender:</strong> {{ $data->gender }}</p>
            <p><strong>Email:</strong> {{ $data->email }}</p>
            <p><strong>Phone Number:</strong> {{ $data->phno }}</p>
            <p><strong>Father's Name:</strong> {{ $data->fathername }}</p>
            <p><strong>Mother's Name:</strong> {{ $data->mothername }}</p>
            <p><strong>Address:</strong> {{ $data->address }}</p>
            <p><strong>City:</strong> {{ $data->city }}</p>
            <p><strong>State:</strong> {{ $data->state }}</p>
            <p><strong>PinCode:</strong> {{ $data->pincode }}</p>
        </section>
        @endforeach
        <p>Thank you For Registration !</p>
    </div>
</body>
</html>
