$(document).ready(function () {
    $("#insertForm").validate({
        rules: {
            name: {
                required: true,
            },
            gender: {
                required: true,
            },
            email: {
                required: true,
            },
            phno: {
                required: true,
            },
            fathername: {
                required: true,
            },
            mothername: {
                required: true,
                minlength: 1,
            },
            address: {
                required: true,
            },
            city: {
                required: true,
            },

            State: {
                required: true,
            },
            pincode: {
                required: true,
            },
            course: {
                required: true,
            },
            studimg: {
                required: true,
            },
        },
        messages: {
            name: {
                required: "This feild is required",
            },
            gender: {
                required: "This feild is required",
            },
            email: {
                required: "This feild is required",
            },
            phno: {
                required: "This feild is required",
            },
            fathername: {
                required: "This feild is required",
            },
            mothername: {
                required: "This feild is required",
            },
            address: {
                required: "This feild is required",
            },
            city: {
                required: "This feild is required",
            },

            State: {
                required: "This feild is required",
            },
            pincode: {
                required: "This feild is required",
            },
            course: {
                required: "This feild is required",
            },
            studimg: {
                required: "This feild is required",
            },
        },
        errorPlacement: function (error, element) {
            if (
                element.attr("type") == "radio" ||
                element.attr("type") == "checkbox"
            ) {
                error.insertBefore(element.first());
            } else {
                error.insertAfter(element);
            }
        },
    });
});

$("#btnsubmit").click(function () {
    if ($("#insertForm").valid()) {
        $("#insertForm").submit();
    }
});
